package com.example.demo.entities;

public class Policy {
    private Integer policyId;
    private Integer groupId;
    private Integer officeId;
    private Integer branchId;
    private String policyName;
    private Integer policyTerm;
    private String policyType;
    private Integer policyCount;
}
