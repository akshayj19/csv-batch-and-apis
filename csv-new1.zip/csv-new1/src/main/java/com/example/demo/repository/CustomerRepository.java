package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.Customer;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {
    @Query("from Customer where policyPayPeriod =3 AND policyPremiumAmount<=50000 order by policyHolderName")
    List<Customer> getdetails();

   List<Customer> findByPolicyId(int policyId);

    @Query(" from Customer where policyPremiumAmount >= 100000 AND policyPayPeriod =6 ")
    List<Customer> getinformation();

    @Query(value="SELECT min (policyPremiumAmount)  FROM Customer policyPremiumAmount ")
    List<Customer> getbig();

}



