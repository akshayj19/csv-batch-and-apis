package com.example.demo.Service;

import com.example.demo.entities.Customer;

import java.util.List;

public interface CustomerService {
   public List<Customer>  getCustomers();


 public   Customer getCustomer(int customerId);

   public  List<Customer> getDetails();

   public String deleteById(int id);

    public  List<Customer> getmaximum();
}
