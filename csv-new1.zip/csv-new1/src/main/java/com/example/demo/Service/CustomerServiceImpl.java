package com.example.demo.Service;

import com.example.demo.entities.Customer;
import com.example.demo.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {


    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public List<Customer> getCustomers() {
        // TODO Auto-generated method stub
        return customerRepository.getdetails();
    }

    @Override
    public Customer getCustomer(int customerId) {
        return customerRepository.getReferenceById(customerId);
    }

    @Override
    public List<Customer> getDetails() {
        return customerRepository.getinformation();
    }


    @Override
    public String deleteById(int id) {
        int counter=0;
        List<Customer> customer = customerRepository.findByPolicyId(id);
        for (Customer c : customer) {
            String date = c.getCreationDate();
            String[] dateString = date.split("/");
            if (dateString[2] == "2015") {
                customerRepository.deleteById(c.getCustomerId());
                ++counter;
            }

        }

return "no of the customer record deleted are: "+counter;
    }

    @Override
    public List<Customer> getmaximum() {
        return customerRepository.getbig();
    }
}





